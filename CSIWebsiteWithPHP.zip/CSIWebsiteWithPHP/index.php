<?php
header("Location: CSI/view/login.php"); /* Redirect browser */
exit();