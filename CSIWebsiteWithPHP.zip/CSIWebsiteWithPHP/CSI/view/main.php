<?php
include "header.php";
?>

<body>
<?php
    include "nav.php";
?>

<!-- Div for database view -->
<div class="container-fluid">
<?php
include 'MySQLTable.php';
?>
</div>
<?php
    include "footer.php";
?>
</body>
</html>