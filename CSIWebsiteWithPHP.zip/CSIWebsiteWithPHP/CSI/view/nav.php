<nav>
    <div class="img_container container-fluid" display="inline-block">
        <a href="../controller/controller.php?action=Main">
            <header class="responsive">
              <img style="border: 5px solid maroon;" class="responsive" src="../img/CSI_BANNERArtboard%201.jpg">
            </header>
        </a>
    </div>

    <div class="topnav" id="myTopnav">
        <a href="../controller/controller.php?action=Main" class=""> Home </a>
        <a href="../controller/controller.php?action=bulletinBoard" class=""> Bulletin Board </a>
        <a href="../controller/controller.php?action=weeklySchedule" class=""> Weekly Schedule </a>
        <a href="../controller/controller.php?action=UserControl" class=""> User Control </a>
        <a href="../controller/controller.php?action=login" class=""> Log Out </a>
        <a href="javascript:void(0);" class="icon" onclick="nav()">
            <i class="fa fa-bars"></i>
        </a>
    </div>
</nav>




