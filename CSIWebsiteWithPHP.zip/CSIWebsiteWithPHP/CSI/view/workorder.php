<?php
include "header.php";
?>

<body>
<?php
    include "nav.php";
?>

<?php
    include "footer.php";
?>
</body>

</html>