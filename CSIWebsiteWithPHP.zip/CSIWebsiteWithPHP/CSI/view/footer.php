<footer>
    <div class="container-fluid responsive" style="background-color: darkgray">
        <label> &copy Calibration Services Inc. 2020 </label>
    </div>
</footer>