
<?php include '../view/footer.php'; ?>