    <?php    
        $DB_USER = "s_crswitzer1";
        $DB_PASSWORD = "s_crswitzer1";
        $DB_DATABASE = "s_crswitzer1";
        $DB_HOST = "localhost";
        $mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASSWORD, $DB_DATABASE);
    ?>