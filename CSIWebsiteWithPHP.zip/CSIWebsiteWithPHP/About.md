PHP and MVC format for final CSI website
